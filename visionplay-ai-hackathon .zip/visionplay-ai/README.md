# VisionPlay AI — Hackathon Demo

A TV-first entertainment prototype with AI-style recommendations, sports demo data, family-safe filtering, fitness/family categories, favourites, and an HTML5 video player.

## Run
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm start`
5. Visit `http://localhost:4000`

Frontend is in `public/index.html`; Express API is in `server.js`.

## API routes
- `GET /api/health`
- `GET /api/catalogue`
- `POST /api/recommend` with `{ "prompt": "family workout", "familyMode": true }`
- `GET /api/summary/:id`
- `GET /api/sports` (explicitly sample/demo data)

## Fire OS / Vega OS
This is a web demo and shared UI starting point, not a certified TV app package. Test on the target device for remote D-pad navigation, browser engine support, audio/video codecs, and packaging. Fire OS and Vega OS require separate platform-specific packaging workflows. Sample MP4 is public demo media; for judging, use a licensed local/hosted video you control and test it on the actual device. This prototype does not access microphone or camera and does not provide real live sports feeds.
